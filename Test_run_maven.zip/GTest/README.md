# training for devops freshers
